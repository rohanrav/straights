#ifndef ACTION_H
#define ACTION_H

enum class Action { PLAY = 0, DISCARD, DECK, QUIT, RAGEQUIT };

#endif
