#ifndef SUIT_H
#define SUIT_H

enum class Suit { CLUBS = 0, DIAMONDS, HEARTS, SPADES };

#endif
